from layers import *

x = [[0, 0],
     [0, 1],
     [1, 0],
     [1, 1], ]
y = [0,
     1,
     1,
     0]

input_x = np.asarray(x, dtype=np.float32)
output_y = np.asarray(y, dtype=np.float32).reshape(-1, 1)

layers = [FullyConnected(2, 2),
          Sigmoid(),
          FullyConnected(1, 2)]
mymlp = MultiLayerPerceptron(layers, SigmoidMSELoss(), Sigmoid())

print(mymlp)

mymlp.train_mode()
losses_run = []
for _ in range(5000):
    _, loss = mymlp.forward(input_x, output_y)
    mymlp.backward()
    print(mymlp.optimize(0.475))
    print('Loss', loss)
    losses_run.append(loss)

mymlp.eval_mode()
out, _ = mymlp.forward(input_x)

losses = []
lrs = [0.45, 0.475, 0.5]

for lr in lrs:
    layers = [FullyConnected(2, 2),
              Sigmoid(),
              FullyConnected(1, 2)]
    mymlp = MultiLayerPerceptron(layers, SigmoidMSELoss(), Sigmoid())

    mymlp.train_mode()
    losses_run = []
    for _ in range(5000):
        _, loss = mymlp.forward(input_x, output_y)
        mymlp.backward()
        print(mymlp.optimize(lr))
        print('Loss', loss)
        losses_run.append(loss)
    losses.append(losses_run)


for lr, run in zip(lrs, losses):
    plt.plot(run, label='lr={}'.format(lr))
    plt.legend()
plt.xlabel('Epoch')
plt.ylabel('Mean Square Error')
plt.savefig('xor_loss_vs_lr.png')
plt.clf()
